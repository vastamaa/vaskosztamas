﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pong
{
    public partial class Form1 : Form
    {
        bool goup;
        bool godown;
        int speed = 5;
        int ballx = 5;
        int bally = 5;
        int playerPoint = 0;
        int cpuPoint = 0;

        public Form1()
        {
            InitializeComponent();
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
        }

        private void keyisdown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.W)
            {
                goup = true;
            }

            if (e.KeyCode == Keys.S)
            {
                godown = true;
            }
        }

        private void keyisup(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.W)
            {
                goup = false;
            }

            if (e.KeyCode == Keys.S)
            {
                godown = false;
            }
        }
        private void timerTick(object sender, EventArgs e)
        {
            playerScore.Text = "" + playerPoint;
            cpuScore.Text = "" + cpuPoint;

            ball.Top -= bally;
            ball.Left -= ballx;

            cpu.Top += speed;
            
            if (playerPoint < 10)
            {
                if (cpu.Top <= 0 || cpu.Top >= 455)
                {
                    speed = -speed;
                }
            }

            if (ball.Left < 0)
            {
                ball.Left = 434; 
                ballx = -ballx; 
                ballx -= 1; 
                cpuPoint++; 
            }

            if (ball.Left + ball.Width > ClientSize.Width)
            {
                ball.Left = 434;  
                ballx = -ballx; 
                ballx += 1; 
                playerPoint++; 
            }

            if (ball.Top < 0 || ball.Top + ball.Height > ClientSize.Height)
            {
                bally = -bally;
            }

            if (ball.Bounds.IntersectsWith(player.Bounds) || ball.Bounds.IntersectsWith(cpu.Bounds))
            {
                ballx = -ballx;
            }

            if (goup && player.Top > 0)
            {
                player.Top -= 8;
            }

            if (godown && player.Top < 455)
            {
                player.Top += 8;
            }

            if (playerPoint >= 10)
            {
                
                result.Text = "Gratulálok, győztél!";
                gameTimer.Stop();

                DialogResult dialogResult = MessageBox.Show("Szeretnél új játékot indítani?", "Új játék", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (dialogResult == DialogResult.Yes)
                {
                    cpuPoint = 0;
                    playerPoint = 0;
                    ball.Top -= bally;
                    ball.Left -= ballx;
                    result.Text = "";
                    gameTimer.Start();
                }
                else if (dialogResult == DialogResult.No)
                {
                    Application.Exit();
                }
            }

            if (cpuPoint >= 10)
            {
                result.Text = "A CPU nyert, te vesztettél!";
                gameTimer.Stop();

                DialogResult dialogResult = MessageBox.Show("Szeretnél új játékot indítani?", "Új játék", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (dialogResult == DialogResult.Yes)
                {
                    cpuPoint = 0;
                    playerPoint = 0;
                    ball.Top -= bally;
                    ball.Left -= ballx;
                    result.Text = "";
                    gameTimer.Start();
                }
                else if (dialogResult == DialogResult.No)
                {
                    Application.Exit();
                }
            }
        }
    }
}
